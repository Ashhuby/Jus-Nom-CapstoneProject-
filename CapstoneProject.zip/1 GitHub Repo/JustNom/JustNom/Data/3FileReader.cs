﻿using System;
using System.IO;    //Needed for StreamReader
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Data
{
    public static class FileReader
    {

        public static string[] ReadFromFile(string pPath)
        {
            // Specify the path to your text file
            string Path = pPath;

            try
            {
                // Read all lines from the file and store them in a string array
                string[] lines = File.ReadAllLines(Path);

                // Create a new string array to store the lines
                string[] linesArray = new string[lines.Length];

                // Copy each line to the new array
                lines.CopyTo(linesArray, 0);

                return linesArray;
 
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("File not found.");
                return new string[0];   // To ensure all code paths return a value I create an emprty string array to be returned in case of error.
            }
            catch (IOException ex)
            {
                Console.WriteLine("Error reading the file: " + ex.Message);
                return new string[0];
            }
        }


    }
}

        