﻿using JustNom.Menu;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Data
{
    //This class is responsible for the formatting and data gathering of lines provided by the file reading class.

    public class FormatMethods
    {
        public FormatMethods()
        {
            
        }
        public static void NameFormat(string pNameLine)
        {
            //The name format is very simple so all we have to do is create a string with only text after the ':'
            int startIndex = pNameLine.IndexOf(':') + 1;
            string NameOnly = pNameLine.Substring(startIndex, pNameLine.Length - startIndex);
            Console.WriteLine(NameOnly);
        }

        public static string ReturnRestaurantName(string pLine)
        {
            int startIndex = pLine.IndexOf(':') + 1;
            string NameOnly = pLine.Substring(startIndex, pLine.Length - startIndex);
            return NameOnly;
        }

        /// <summary>
        /// To format toppings we use a similar trick to NameFormat to remove all unnecessary text so get left with a string of only data
        /// There is a pattern to the topping format (name1,price1,name2,price2,...)
        /// So we can filter out the text until we get just an array of the names and prices and group them that way
        /// </summary>
        /// <param name="pNameLine"></param>
        public static void ToppingFormat(string pNameLine)
        {

            //Extract the toppings part from the input string
            int startIndex = pNameLine.IndexOf('[') + 1;
            int endIndex = pNameLine.IndexOf(']');
            string toppingsPart = pNameLine.Substring(startIndex, endIndex - startIndex);

            //Remove the '<' and '>' characters
            toppingsPart = toppingsPart.Replace("<", "").Replace(">", "");

            //Split the string by ">,<" to get individual topping strings
            string[] toppingStrings = toppingsPart.Split(new string[] { ">,<" }, StringSplitOptions.None);
            string[] FilteredToppingString = toppingStrings[0].Split(',');

            //Initialize a dictionary to store the toppings and their prices
            Dictionary<string, int> ToppingDictionary = new Dictionary<string, int>();

            //Parse and add i as the name and i as the price iterating 2 elements at a time as they come as a pair
            for (int i = 0; i < FilteredToppingString.Length; i += 2)
            {
                string ElementName = FilteredToppingString[i];
                int ElementPrice = int.Parse(FilteredToppingString[i + 1]);
                ToppingDictionary.Add(ElementName, ElementPrice);
            }

            //Prints the keyvalue pairs in the Topping dictionary, Use this to test REMOVE THIS BEFORE SHIPPING
            Console.WriteLine("Name: Price");
            foreach (var topping in ToppingDictionary)
            {
                Console.WriteLine($"{topping.Key}: {topping.Value}");
            }


            /*
            //To look up a value for a given key
            if (ToppingDictionary.ContainsKey("cheese"))
            {
                int value = ToppingDictionary["cheese"];
                Console.WriteLine(value);
            }

            //Directly find and store value 
            int HamPrice = ToppingDictionary["ham"];
            Console.WriteLine(HamPrice);

            //This is another method which may be better as it does not throw an exeption and returns boolean value
            if (ToppingDictionary.TryGetValue("Cheese", out int value1))
            {
                Console.WriteLine($"The value for 'Cheese' is: {value1}");
            }
            else
            {
                Console.WriteLine("The key 'Cheese' does not exist in the dictionary.");
            }
            */
        }

        public static Dictionary<string,double> ReturnToppingDictionary(string pLine)
        {

            //Extract the toppings part from the input string
            int startIndex = pLine.IndexOf('[') + 1;
            int endIndex = pLine.IndexOf(']');
            string toppingsPart = pLine.Substring(startIndex, endIndex - startIndex);

            //Remove the '<' and '>' characters
            toppingsPart = toppingsPart.Replace("<", "").Replace(">", "");

            //Split the string by ">,<" to get individual topping strings
            string[] toppingStrings = toppingsPart.Split(new string[] { ">,<" }, StringSplitOptions.None);
            string[] FilteredToppingString = toppingStrings[0].Split(',');

            //Initialize a dictionary to store the toppings and their prices
            Dictionary<string, double> ToppingDictionary = new Dictionary<string, double>();

            //Parse and add i as the name and i as the price iterating 2 elements at a time as they come as a pair
            for (int i = 0; i < FilteredToppingString.Length; i += 2)
            {
                string ElementName = FilteredToppingString[i];
                double ElementPrice = double.Parse(FilteredToppingString[i + 1]);
                double ElementValue = ElementPrice / 100;
                ToppingDictionary.Add(ElementName, ElementValue);
            }

            return ToppingDictionary;
        }

        public static Dictionary<string, double> ReturnGarnishDictionary(string pLine)
        {

            //Extract the toppings part from the input string
            int startIndex = pLine.IndexOf('[') + 1;
            int endIndex = pLine.IndexOf(']');
            string GarnishPart = pLine.Substring(startIndex, endIndex - startIndex);

            //Remove the '<' and '>' characters
            GarnishPart = GarnishPart.Replace("<", "").Replace(">", "");

            //Split the string by ">,<" to get individual topping strings
            string[] GarnishStrings = GarnishPart.Split(new string[] { ">,<" }, StringSplitOptions.None);
            string[] FilteredGarnishString = GarnishStrings[0].Split(',');

            //Initialize a dictionary to store the toppings and their prices
            Dictionary<string, double> GarnishDictionary = new Dictionary<string, double>();

            //Parse and add i as the name and i as the price iterating 2 elements at a time as they come as a pair
            for (int i = 0; i < FilteredGarnishString.Length; i += 2)
            {
                string ElementName = FilteredGarnishString[i];
                double ElementPrice = double.Parse(FilteredGarnishString[i + 1]);
                double ElementValue = ElementPrice / 100;
                GarnishDictionary.Add(ElementName, ElementValue);
            }

            return GarnishDictionary;
        }



        public static string ReturnToppingLine(string fileName)
        {
            try
            {
                string[] lines = File.ReadAllLines(fileName);

                if (lines.Length >= 3)
                {
                    return lines[1]; // Lines are zero-indexed, so the second line is at index 1
                }
                else
                {
                    return "The file does not have enough lines.";
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions (e.g., file not found, access denied) and return a meaningful message
                return $"An error occurred: {ex.Message}";
            }
        }

        //Same as Toppings method (I would use the same method and have the line number as a parameter but that would lead to less readabilty as calling the method with parameter 2 or 3 
        public static string ReturnGarnishLine(string fileName)
        {
            try
            {
                string[] lines = File.ReadAllLines(fileName);

                if (lines.Length >= 3)
                {
                    return lines[2]; // Lines are zero-indexed, so the third line is at index 2
                }
                else
                {
                    return "The file does not have enough lines.";
                }
            }
            catch (Exception ex)
            {
                
                return $"An error occurred: {ex.Message}";
            }
        }


        public static string[,] PizzaRecipeFormat(string pRecipeLine)
        {
            //String[] return type holding infomation for FoodType,RecipeName,Toppings[],Price
            string[] FoodType = new string[1];  //Type,Name and Price will only need to hold 1 value
            string[] FoodName = new string[1];
            string[] FoodIngredient = new string[6];    //I chose the max igendients value to be 6, but this can be changed to any value
            string[] FoodBasePrice = new string[1];

            string[,] PizzaRecipe = new string[4, 6];    //The final output string[,] array will be multidimensional

            string[] SplitStringsIntoChunks = pRecipeLine.Split(':');   //We first split the input string to multiple workable components

            //This handles data showing if Recipe is for a Pizza or Burger
            FoodType[0] = SplitStringsIntoChunks[0];


            //This handles RecipeName
            int commaIndex = SplitStringsIntoChunks[2].IndexOf(',');
            string NameString = SplitStringsIntoChunks[2].Substring(0, commaIndex);
            FoodName[0] = NameString;

            //This handles the Ingredients/ Extra toppings
            string[] IncludedToppings;
            int StartIndex = 1;
            int EndIndex = SplitStringsIntoChunks[3].Length - 7;
            string ExtractedToppings = SplitStringsIntoChunks[3].Substring(StartIndex, EndIndex - StartIndex);
            IncludedToppings = ExtractedToppings.Split(',');
            for (int i = 1; i < IncludedToppings.Length; i++)
            {
                IncludedToppings[i] = IncludedToppings[i].Trim();   //Get rid of white spaces after the comma
            }
            //Add the included topping
            for (int i = 0; i < IncludedToppings.Length; i++)
            {
                PizzaRecipe[2, i] = IncludedToppings[i];
            }

            //This handles RecipePrice
            SplitStringsIntoChunks[4] = SplitStringsIntoChunks[4].Trim('>');
            string RecipePrice = SplitStringsIntoChunks[4];
            double RecipePricedouble = Convert.ToDouble(RecipePrice) / 100; //Parse to double so we can /100 then back to string to be copied
            string RecipePriceString = Convert.ToString(RecipePricedouble);
            FoodBasePrice[0] = RecipePriceString;

            //Add FoodType, FoodName and FoodPrice
            PizzaRecipe[0, 0] = FoodType[0];
            PizzaRecipe[1, 0] = FoodName[0];
            PizzaRecipe[3, 0] = FoodBasePrice[0];

            //Return the 2D array of the Recipe infomation
            return PizzaRecipe;
        }

        //Prints recipes (items on the menu) in a readable format
        public static void PrintRecipes(string[,] pString)
        {
            //This centers the price, it no longer is affected by the length of the FoodItem Name
            int TitleLength = pString[0, 0].Length + pString[1, 0].Length;
            int SpaceCount = 30 - TitleLength;
            string EmptyGap = new string(' ', SpaceCount);

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(pString[1, 0] + " " + pString[0,0] + (EmptyGap) + "£" + pString[3,0]);
            Console.ResetColor();

            for (int i = 0; i < pString.GetLength(0); i++)
            {
                try
                {
                    Console.WriteLine(pString[2, i]);
                }
                catch
                {
                    Console.WriteLine("Null");
                }
            }
            
        }

        public static void Print2DArray(string[,] pString)
        {
            // Display the 2D array
            for (int row = 0; row < pString.GetLength(0); row++) // Iterate through the rows
            {
                for (int col = 0; col < pString.GetLength(1); col++) // Iterate through the columns
                {
                    try
                    {
                        Console.Write(pString[row, col] + " ");
                    }
                    catch
                    {
                        Console.WriteLine("*");
                    }
                }
                Console.WriteLine();
            }
        }
    }
}


