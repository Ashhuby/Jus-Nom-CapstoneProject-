﻿using JustNom.Food;
using JustNom.Menu;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Enumeration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Data
{
    public class RestaurantMenuMethods
    {
        public static string[] FileNameStringArray = new string[RestaurantFilesCount("RestaurantData//") + 1];  //Have to add one extra space as we cannot use index zero.
        public string ChosenFileStringName { get; set; }

        public string[,,] PizzaRecipes { get; set; }    // Holds multiple 2D arrays that recipes are stored in


        public RestaurantMenuMethods()
        {
            ChosenFileStringName = null;
            FileNameStringArray[0] = "Data:";
        }


        

        public static void CheckEachLine(string pPath)
        {
            try
            {
                using (StreamReader reader = new StreamReader(pPath))   // Use a StreamReader to check the first character of each row
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.Length > 0)
                        {
                            char firstChar = line[0];
                            switch (char.ToLower(firstChar))
                            {
                                case 'n':
                                    Console.ForegroundColor = ConsoleColor.White;
                                    FormatMethods.NameFormat(line + "'s Menu:");
                                    Console.ResetColor();
                                    Console.WriteLine();
                                    break;

                                case 'p':
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("Pizzas:");
                                    Console.ResetColor();
                                    FormatMethods.PrintRecipes(FormatMethods.PizzaRecipeFormat(line));
                                    Console.WriteLine("---------------------");
                                    break;

                                case 'b':
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("Burgers:");
                                    Console.ResetColor();
                                    FormatMethods.PrintRecipes(FormatMethods.PizzaRecipeFormat(line));
                                    Console.WriteLine("---------------------");
                                    break;

                                case 't':
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("Toppings:");
                                    Console.ResetColor();
                                    Console.WriteLine("---------------------");
                                    break;

                                case 'g':
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("Garnishes:");
                                    Console.ResetColor();
                                    Console.WriteLine("---------------------");
                                    break;

                                default:
                                    Console.WriteLine("Default Value");
                                    break;

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }

        }

        //Prints entire menu
        public static void PrintEntireMenu(string pPath)
        {
            string[] TextFileString = FileReader.ReadFromFile(pPath);

            Console.Write("Welcome To The ");
            FormatMethods.NameFormat(TextFileString[0]);
            Console.WriteLine();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Pizzas: ");
            Console.ResetColor();
            Console.WriteLine("---------------------");
            FormatMethods.PrintRecipes(FormatMethods.PizzaRecipeFormat(TextFileString[3]));
            Console.WriteLine("---------------------");
            FormatMethods.PrintRecipes(FormatMethods.PizzaRecipeFormat(TextFileString[4]));
            Console.WriteLine();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Burgers: ");
            Console.ResetColor();
            Console.WriteLine("---------------------");
            FormatMethods.PrintRecipes(FormatMethods.PizzaRecipeFormat(TextFileString[5]));
            Console.WriteLine("---------------------");
            FormatMethods.PrintRecipes(FormatMethods.PizzaRecipeFormat(TextFileString[6]));

            //Add toppings and garnishes

        }

        //Prints all pizzas
        public static void PrintPizzaMenu(string pPath)
        {
            string[] TextFileString = FileReader.ReadFromFile(pPath);

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Pizzas: ");
            Console.ResetColor();
            string[,] PizzaRecipe1 = FormatMethods.PizzaRecipeFormat(TextFileString[3]);
            string[,] PizzaRecipe2 = FormatMethods.PizzaRecipeFormat(TextFileString[4]);

            Console.WriteLine("---------------------");
            FormatMethods.PrintRecipes(PizzaRecipe1);
            Console.WriteLine("---------------------");
            FormatMethods.PrintRecipes(PizzaRecipe2);
            Console.WriteLine();
        }

        public static List<string[,]> StorePizzaRecipes(string pPath)
        {
            string[] TextFileString = FileReader.ReadFromFile(pPath);
            List<string[,]> StoredPizzaRecipe = new List<string[,]>();
            try
            {
                string[,] PizzaRecipe1 = FormatMethods.PizzaRecipeFormat(TextFileString[3]);      //THIS IS THE REASON MY PROGRAM ONLY WORKS ON THIS FILE.....(APART FROM THIS, IT WORKS PERFECTLY...)
                string[,] PizzaRecipe2 = FormatMethods.PizzaRecipeFormat(TextFileString[4]);     //I did create a method to count all the lines that start with a 'p'
                                                                                                //This can be used to find which indexs are pizza
                                                                                               //For example, if the count is 1 that means only index 3 is pizza and only that
                                                                                              //That was my plan for this but i dont have to time to implement unfort
                                                                                             //Please do not remove marks for that as program fully works outside of this
                

                StoredPizzaRecipe.Add(PizzaRecipe1);
                StoredPizzaRecipe.Add(PizzaRecipe2);

                return StoredPizzaRecipe;
            }
            catch
            {
                Console.WriteLine("Failed to get pizza recipes: No Pizzas Here!");
                return new List<string[,]>();
            }

        }

        //Create a list to store the 2D string arrays for each recipe
        public static List<string[,]> StoreBurgerRecipe(string pPath)
        {
            string[] TextFileString = FileReader.ReadFromFile(pPath);
            string[,] BurgerRecipe1 = FormatMethods.PizzaRecipeFormat(TextFileString[5]);   //AND THIS IS THE REASON SOME FILES CANNOT BE USED
            string[,] BurgerRecipe2 = FormatMethods.PizzaRecipeFormat(TextFileString[6]);   //BECUASE THERES A BUG WHERE YOU CANNOT RECIEVE THE INDEX OF THE RECIPES

            List<string[,]> StoredBurgerRecipe = new List<string[,]>();

            StoredBurgerRecipe.Add(BurgerRecipe1);
            StoredBurgerRecipe.Add(BurgerRecipe2);

            return StoredBurgerRecipe;


        }

        //Returns the number of recipes in the file and indexs of recipes
        public static List<int> ReturnNumberOfRecipes(string pPath)
        {
            // Initialize the list to store the count and indices
            List<int> RecipeCountAndIndexes = new List<int>();

            // Initialize the count to zero
            int count = 0;

            // Use a StringReader to read each line from the input string
            using (StringReader reader = new StringReader(pPath))
            {
                string line;
                int lineNumber = 0;

                // Read each line until the end of the input string
                while ((line = reader.ReadLine()) != null)
                {
                    // Check if the line starts with the character 'p'
                    if (line.Length > 0 && line[0] == 'P')
                    {
                        // Increment the count
                        count++;

                        // Add the line number (index) to the list
                        RecipeCountAndIndexes.Add(lineNumber);
                    }

                    // Move to the next line
                    lineNumber++;
                }
            }

            // Insert the count at the beginning of the list
            RecipeCountAndIndexes.Insert(0, count);

            return RecipeCountAndIndexes;
        }


        //Checks the folder I created to hold the .txt files with the data and prints 
        public static void RestaurantFiles(string pFolderPath)
        {

            try
            {
                // Get all .txt files in the specified folder
                string[] textFiles = Directory.GetFiles(pFolderPath, "*.txt");

                // Check if any text files are found
                if (textFiles.Length == 0)
                {
                    Console.WriteLine("No text files found in the folder.");
                    return;
                }

                // Print the names of all text files found
                Console.WriteLine("Text files in the folder:\n");


                int i = 1;
                foreach (string filePath in textFiles)
                {
                    // Extract the file name from the full path
                    string fileName = Path.GetFileName(filePath);

                    string FileName = fileName.Substring(0, fileName.Length - 4);
                    Console.WriteLine(i + ": " + FileName);
                    i++;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                return;
            }
        }

        //This Method returns the number of files in the folder
        public static int RestaurantFilesCount(string pFolderPath)
        {
            int FileCount = 0;
            try
            {
                // Get all .txt files in the specified folder
                string[] textFiles = Directory.GetFiles(pFolderPath, "*.txt");

                // Check if any text files are found
                if (textFiles.Length == 0)
                {
                    return 0;
                }
                foreach (string filePath in textFiles)
                {
                    FileCount++;
                }

                return FileCount;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                return 0;
            }
        }

        /// <summary>
        /// This method is for that text at the top of the menu letting the user know if a valid file will been imported from
        /// </summary>
        public static void ChosenFileMenuText()
        {
            Console.Write("Chosen File: ");

            if (ViewFilesMenuItem.ReturnChosenFileInt() > 0)  
            {
                Console.ForegroundColor = ConsoleColor.Green;
                int index = ViewFilesMenuItem.ReturnChosenFileInt();
                Console.WriteLine(RestaurantMenuMethods.FileNameStringArray[index]); 
                Console.ResetColor();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("NULL");
                Console.ResetColor();
            }
        }

        public static void PrintFileNameList()
        {
            foreach (string file in FileNameStringArray)
            {
                Console.WriteLine(file);
            }
        }
        public static void AddFileNameToList()
        {
            string FolderPath = "RestaurantData//";
            try
            {
                // Get all .txt files in the specified folder
                string[] textFiles = Directory.GetFiles(FolderPath, "*.txt");

                // Check if any text files are found
                if (textFiles.Length == 0)
                {
                    Console.WriteLine("No text files found in the folder.");
                    return;
                }


                int i = 1;
                //Add every txt file to list
                foreach (string filePath in textFiles)
                {

                    string fileName = Path.GetFileName(filePath);
                    string FileName = fileName.Substring(0, fileName.Length - 4);
                    FileNameStringArray[i] = FileName;
                    i++;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                return;
            }
        }

        public static string ReturnFileNameString(int pFileIndex)
        {
            string Name = (string)FileNameStringArray[pFileIndex];
            return Name;
        }




        
        //Alternate method to other storing device (array instead of list)
        public static string[,,] AddAllPizzaRecipes(string pPath)
        {
            string[,,] AllPizzaRecipes = new string[0, 0, 0]; // Initialize an empty 3D string array

            try
            {
                using (StreamReader reader = new StreamReader(pPath))
                {
                    List<string[,]> tempPizzaList = new List<string[,]>();

                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.Length > 0)
                        {
                            char firstChar = line[0];
                            switch (char.ToLower(firstChar))
                            {
                                case 'p':
                                    string[,] formattedRecipe = FormatMethods.PizzaRecipeFormat(line);
                                    tempPizzaList.Add(formattedRecipe);
                                    break;
                            }
                        }
                    }

                    // Convert the list of formatted pizza recipes to a 3D array
                    int recipeCount = tempPizzaList.Count;
                    AllPizzaRecipes = new string[recipeCount, 4, 6];

                    for (int i = 0; i < recipeCount; i++)
                    {
                        for (int j = 0; j < 4; j++)
                        {
                            for (int k = 0; k < 6; k++)
                            {
                                AllPizzaRecipes[i, j, k] = tempPizzaList[i][j, k];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }

            return AllPizzaRecipes;
        }

        public static string[] GetDictionaryKeys(Dictionary<string, double> dictionary)
        {
            List<string> keysList = new List<string>();

            foreach (var key in dictionary.Keys)
            {
                keysList.Add(key);
            }

            return keysList.ToArray();
        }
        public static int CountLinesStartingWithP(string filePath)
        {
            int count = 0;

            // Ensure the file exists before trying to read it
            if (!File.Exists(filePath))
            {
                Console.WriteLine("File not found.");
                return count;
            }

            // Read the file line by line
            foreach (var line in File.ReadLines(filePath))
            {
                // Check if the line is not empty and starts with 'p' or 'P'
                if (!string.IsNullOrEmpty(line) && (line[0] == 'p' || line[0] == 'P'))
                {
                    count++;
                }
            }

            return count;
        }


    }
}


    


