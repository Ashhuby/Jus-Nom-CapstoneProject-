﻿using JustNom.Data;
using JustNom.Menu;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Food
{
    internal class AddGarnishesMenuItem : MenuItem
    {
        private Food.Burger _Burger;

        public AddGarnishesMenuItem(Food.Burger pBurger)
        {
            _Burger = pBurger;
        }

        public override string MenuText()
        {
            return "Add Garnish to Burger";
        }

        public override void Select()
        {
            // Get the garnish Line from file
            int number = ViewFilesMenuItem.ReturnChosenFileInt();
            string filePath = $"RestaurantData//{RestaurantMenuMethods.ReturnFileNameString(number)}.txt";
            string GarnishLine = FormatMethods.ReturnGarnishLine(filePath); // Format the line to only get info and put into dictionary

            if (string.IsNullOrEmpty(GarnishLine))
            {
                Console.WriteLine("Error: garnish line is empty or null.");
                return;
            }

            Dictionary<string, double> GarnishDictionary = FormatMethods.ReturnGarnishDictionary(GarnishLine);

            if (GarnishDictionary == null || GarnishDictionary.Count == 0)
            {
                Console.WriteLine("Error: garnish dictionary is empty or null.");   // Another base case
                return;
            }

            Console.WriteLine("Name: Price");
            int i = 1;  // Incrementing int i so there are numbers next to the options 
            foreach (var garnish in GarnishDictionary)          // Prints the dictionary
            {
                Console.WriteLine($"{i}. {garnish.Key}: {garnish.Value}");
                i++;
            }

            string[] keyNames = RestaurantMenuMethods.GetDictionaryKeys(GarnishDictionary);

            if (keyNames == null || keyNames.Length == 0)
            {
                Console.WriteLine("Error: No garnishs available.");
                return;
            }

            Console.WriteLine();
            int selection = ConsoleHelpers.GetIntegerInRange(1, GarnishDictionary.Count, "Choose a garnish you would like to add\n") ; // Ask User

            // Check if _Pizza.FoodExtra is null and initialize if needed
            if (_Burger.FoodExtra == null)
            {
                _Burger.FoodExtra = new string[0]; // Initialize if null
            }

            // Use a temporary variable to resize the array
            string[] tempFoodExtra = _Burger.FoodExtra;
            Array.Resize(ref tempFoodExtra, tempFoodExtra.Length + 1);
            tempFoodExtra[^1] = keyNames[selection - 1];

            // Assign the resized array back to the property
            _Burger.FoodExtra = tempFoodExtra;

            // Add the value of the selected key to _Pizza.FoodPrice
            _Burger.FoodPrice += GarnishDictionary[keyNames[selection - 1]];

            Console.WriteLine();
        }
    }
}
