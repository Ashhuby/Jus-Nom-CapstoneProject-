﻿using JustNom.Data;
using JustNom.Menu;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Food
{
    internal class AddToppingsMenuItem : MenuItem
    {
        private Food.Pizza _Pizza;
 
        public AddToppingsMenuItem(Food.Pizza pPizza)
        {
            _Pizza = pPizza;
        }

        public override string MenuText()
        {
            return "Add Topping to Pizza";
        }

        public override void Select()
        {
            // Get the Topping Line from file
            int number = ViewFilesMenuItem.ReturnChosenFileInt();
            string filePath = $"RestaurantData//{RestaurantMenuMethods.ReturnFileNameString(number)}.txt";
            string toppingLine = FormatMethods.ReturnToppingLine(filePath); // Format the line to only get info and put into dictionary

            if (string.IsNullOrEmpty(toppingLine))
            {
                Console.WriteLine("Error: Topping line is empty or null.");
                return;
            }

            Dictionary<string, double> toppingDictionary = FormatMethods.ReturnToppingDictionary(toppingLine);

            if (toppingDictionary == null || toppingDictionary.Count == 0)
            {
                Console.WriteLine("Error: Topping dictionary is empty or null.");   // Another base case
                return;
            }

            Console.WriteLine("Name: Price");
            int i = 1;  // Incrementing int i so there are numbers next to the options 
            foreach (var topping in toppingDictionary)          // Prints the dictionary
            {
                Console.WriteLine($"{i}. {topping.Key}: {topping.Value}");
                i++;
            }

            string[] keyNames = RestaurantMenuMethods.GetDictionaryKeys(toppingDictionary);

            if (keyNames == null || keyNames.Length == 0)
            {
                Console.WriteLine("Error: No toppings available.");
                return;
            }

            Console.WriteLine();
            int selection = ConsoleHelpers.GetIntegerInRange(1, toppingDictionary.Count, "Choose a topping you would like to add\n"); // Ask User

            // Check if _Pizza.FoodExtra is null and initialize if needed
            if (_Pizza.FoodExtra == null)
            {
                _Pizza.FoodExtra = new string[0]; // Initialize if null
            }

            // Use a temporary variable to resize the array
            string[] tempFoodExtra = _Pizza.FoodExtra;
            Array.Resize(ref tempFoodExtra, tempFoodExtra.Length + 1);
            tempFoodExtra[^1] = keyNames[selection - 1];

            // Assign the resized array back to the property
            _Pizza.FoodExtra = tempFoodExtra;

            // Add the value of the selected key to _Pizza.FoodPrice
            _Pizza.FoodPrice += toppingDictionary[keyNames[selection - 1]];

            Console.WriteLine();


        }
    }
}
