﻿using JustNom.Menu;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Food
{
    internal class EditBurgerMenu : EditFoodMenu
    {

        protected Food.Burger _Burger;

        public EditBurgerMenu(Food.Burger pBurger) : base(pBurger)
        {
            _Burger = pBurger;
        }

        public override void CreateMenu()
        {
            _menuItems.Clear();
            Console.Clear();
            Console.WriteLine("Do you want to edit this item?\n1. Yes please\n2. No and its perfect :)\n");
            _menuItems.Add(new AddGarnishesMenuItem(_Burger));
            _menuItems.Add(new ExitMenuItem(this));
        }

    }
}
