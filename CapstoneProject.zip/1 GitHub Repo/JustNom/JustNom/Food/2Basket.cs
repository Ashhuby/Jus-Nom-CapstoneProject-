﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Food
{
    /// <summary>
    /// This is the 'FoodItemManager' AKA the basket where the food in an order in stored.
    /// </summary>
    internal class Basket
    {
        public double TotalCost { get; private set; }
        private static int IdCount = 0;
        public int BasketId { get; private set; }
        //public int NextBasketId { get; private set; }

        
        public List<FoodItem> MyOrder { get; private set; }

        public Basket()
        {
            MyOrder = new List<FoodItem>();
            this.BasketId = ++IdCount;
        }

        public void AddFood(FoodItem pFood)
        {
            
            MyOrder.Add(pFood);
            this.TotalCost += pFood.FoodPrice;
            PrintCurrentBasket();
        }

        public int PrintID()
        {
            return BasketId;
        }


        public double ReturnTotalCost()
        {
            return TotalCost;
        }

        public void PrintCurrentBasket()
        {
            MyOrder.ForEach(item => Console.WriteLine(item));   //Basic Linq Commands as orders are stored in Lists
            Console.WriteLine("Total Cost: £" + ReturnTotalCost());
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (FoodItem food in MyOrder)
            {
                sb.Append(food.ToString() + Environment.NewLine);
            }
            return sb.ToString();
        }

        public void AddDeliveryCharge(Basket pBasket)
        {
            pBasket.TotalCost = pBasket.TotalCost + 2.0;
        }
    }
}
