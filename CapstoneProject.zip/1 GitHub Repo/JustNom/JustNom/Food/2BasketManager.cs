﻿using System.Collections.Generic;
using JustNom.Food;


namespace JustNom.Food
{
    internal class BasketManager
    {
        private List<Basket> _baskets;

        public BasketManager()
        {
            _baskets = new List<Basket>();
        }

        public void AddBasket(Basket basket)
        {
            _baskets.Add(basket);
        }
    }
}
