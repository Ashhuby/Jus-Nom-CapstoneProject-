﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Food
{
    internal class Burger : FoodItem
    {
        //All members were inherited

        // Constructor
        public Burger(string pBurgerName, string[] pBurgerExtra, double pBurgerPrice)
            : base(tFoodType.Burger, pBurgerName, pBurgerExtra, pBurgerPrice)
        {
        }

        // Constructor without any extra toppings
        public Burger(string foodName, double foodPrice)
            : this(foodName, null, foodPrice) // Chaining to the other constructor
        {
        }

        // Implementation of the abstract method
        public override void GetDetails()
        {
            Console.WriteLine($"Name: {FoodName} ");
            Console.WriteLine($"Extras:");

            // Check if _Burger.FoodExtra is not null and contains elements
            if (FoodExtra != null && FoodExtra.Length > 0)
            {
                Console.WriteLine("Selected Extra Garnishes:");
                foreach (var topping in FoodExtra)
                {
                    Console.WriteLine(topping);
                }
            }
            else
            {
                Console.WriteLine("No extra Garnishes selected.");
            }

            Console.WriteLine($"Price: £{FoodPrice}");
        }
        public override string ToString()
        {
            return $"'{FoodName}' £{FoodPrice}." ;
        }

    }
}
