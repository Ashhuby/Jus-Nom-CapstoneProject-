﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Food
{
    internal abstract class FoodItem
    {
        // Create enum for type of food, the project only allows for two types but ive added a couple more to show it can be expanded
        public enum tFoodType
        {
            Pizza,
            Burger,
            Salad,
            MilkShake
            
        }

        // Properties
        public tFoodType FoodType { get; set; }
        public string FoodName { get; set; }
        public string[] FoodExtra { get; set; }
        public double FoodPrice { get; set; }

        protected FoodItem(tFoodType pfoodType, string pfoodName, string[] pfoodExtra, double pfoodPrice)
        {
            FoodType = pfoodType;
            FoodName = pfoodName;
            FoodExtra = pfoodExtra;
            FoodPrice = pfoodPrice;
        }

        // Abstract method to get the details of the food item
        public abstract void GetDetails();
    }



}

