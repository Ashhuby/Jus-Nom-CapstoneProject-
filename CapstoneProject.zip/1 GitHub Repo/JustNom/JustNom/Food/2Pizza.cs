﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Food
{
    internal class Pizza : FoodItem
    {
        //All members were inherited

        // Constructor
        public Pizza(string pPizzaName, string[] pPizzaExtra, double pPizzaPrice)
            : base(tFoodType.Pizza, pPizzaName, pPizzaExtra, pPizzaPrice)
        {
        }

        // Constructor without any extra toppings
        public Pizza(string foodName, double foodPrice)
            : this(foodName,null , foodPrice) // Chaining to the other constructor
        {
            
        }

        // Implementation of the abstract method
        public override void GetDetails()
        {
            Console.WriteLine($"Name: {FoodName} Pizza");
            Console.WriteLine($"Extras:");

            // Check if _Pizza.FoodExtra is not null and contains elements
            if (FoodExtra != null && FoodExtra.Length > 0)
            {
                Console.WriteLine("Selected Extra Toppings:");
                foreach (var topping in FoodExtra)
                {
                    Console.WriteLine(topping);
                }
            }
            else
            {
                Console.WriteLine("No extra toppings selected.");
            }

            Console.WriteLine($"Price: £{FoodPrice}");
        }
        public override string ToString()
        {
            return $"'{FoodName} Pizza', £{FoodPrice}.";
        }
    }
}
