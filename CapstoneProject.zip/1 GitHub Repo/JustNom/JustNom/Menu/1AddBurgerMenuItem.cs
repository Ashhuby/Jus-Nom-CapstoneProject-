﻿using JustNom.Data;
using JustNom.Food;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Menu
{
    internal class AddBurgerMenuItem : MenuItem
    {
        public const string FolderPath = "RestaurantData//";
        private Basket _basket;
        public AddBurgerMenuItem(Basket basket)
        {
            _basket = basket;

        }

        public override string MenuText()
        {
            return "Add Burger";
        }

        public override void Select()
        {
            Console.Clear();
            RestaurantMenuMethods.AddFileNameToList();


            int number = ViewFilesMenuItem.ReturnChosenFileInt();

            if (number == 0)
            {
                Console.WriteLine("You have not chosen a menu to import from.");

            }


            List<string[,]> MyStoredBurgerList = RestaurantMenuMethods.StoreBurgerRecipe($"RestaurantData//{RestaurantMenuMethods.ReturnFileNameString(number)}.txt");

            foreach (var burgerrecipe in MyStoredBurgerList)
            {
                FormatMethods.PrintRecipes(burgerrecipe);
            }


            int selection = ConsoleHelpers.GetIntegerInRange(1, MyStoredBurgerList.Count, "Choose a Burger") - 1;

            string[,] ChosenBurger = MyStoredBurgerList[selection];

            string BurgerName = ChosenBurger[1, 0];
            string BurgerPrice = ChosenBurger[3, 0];
            double Pricedouble = (Convert.ToDouble(BurgerPrice));
            Burger burger = new Burger(BurgerName, Pricedouble);
            _basket.AddFood(burger);
            _basket.ToString();


        }
    }
}
