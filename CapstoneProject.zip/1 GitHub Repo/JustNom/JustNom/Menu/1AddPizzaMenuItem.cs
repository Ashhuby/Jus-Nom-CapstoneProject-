﻿using JustNom.Data;
using JustNom.Food;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Menu
{
    internal class AddPizzaMenuItem : MenuItem
    {
        public const string FolderPath = "RestaurantData//";
        private Basket _basket;
        public AddPizzaMenuItem(Basket basket)
        {
            _basket = basket;
            
        }

        public override string MenuText()
        {
            return "Add Pizza";
        }

        public override void Select()
        {
          
            Console.Clear();
            RestaurantMenuMethods.AddFileNameToList();
            
            
            int number = ViewFilesMenuItem.ReturnChosenFileInt();
            
            if(number == 0)
            {
                Console.WriteLine("You have not chosen a menu to import from.");
                
            }



            List<string[,]> MyStoredPizzaRecipesList = RestaurantMenuMethods.StorePizzaRecipes($"RestaurantData//{RestaurantMenuMethods.ReturnFileNameString(number)}.txt");

            foreach(var recipe in MyStoredPizzaRecipesList)
            {
                FormatMethods.PrintRecipes(recipe);
            }


            int selection = ConsoleHelpers.GetIntegerInRange(1, MyStoredPizzaRecipesList.Count, "\nChoose a Pizza") - 1;

            string[,] ChosenPizza = MyStoredPizzaRecipesList[selection];


            string pizzaName = ChosenPizza[1,0];
            string pizzaPrice = ChosenPizza[3, 0];
            double Pricedouble = (Convert.ToDouble(pizzaPrice));
            Pizza pizza = new Pizza(pizzaName, Pricedouble);
            _basket.AddFood(pizza);
            _basket.ToString();
        }
    }
}
