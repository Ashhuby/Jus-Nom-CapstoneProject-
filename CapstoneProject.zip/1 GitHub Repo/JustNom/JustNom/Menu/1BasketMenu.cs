﻿using JustNom.Data;
using JustNom.Food;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Menu
{
    class BasketMenu : ConsoleMenu
    {
        private Basket MyBasket;

        public BasketMenu(Basket pBasket)
        {
            MyBasket = pBasket;

            
        }
        public override void CreateMenu()
        {
            
            _menuItems.Clear();
            Console.Clear();

            RestaurantMenuMethods.ChosenFileMenuText();
            Console.WriteLine("Order Id:    " + MyBasket.PrintID());

            int number = ViewFilesMenuItem.ReturnChosenFileInt();
            

            


            if (ViewFilesMenuItem.ReturnChosenFileInt() > 0)    //You cannot add fooditems until you have chosen a file to import data from.
            {
                _menuItems.Add(new AddPizzaMenuItem(MyBasket));
                _menuItems.Add(new AddBurgerMenuItem(MyBasket));
            }

            if (MyBasket.MyOrder.Count > 0)         //You are not given the option to edit fooditems unless there is at least one fooditem in the basket.
            {
                _menuItems.Add(new EditExistingFoodItemsMenu(MyBasket));
                _menuItems.Add(new ViewCurrentOrder(MyBasket));
            }

            _menuItems.Add(new ViewFilesMenuItem());

            if (MyBasket.MyOrder.Count > 0)         //Cannot print until theres at least one item in basket.
            {
                _menuItems.Add(new PrintOrderMenuItem(MyBasket));
            }

            BasketManager basketManager = new BasketManager();
            _menuItems.Add(new NewBasketMenuItem(basketManager));
            _menuItems.Add(new ExitMenuItem(this));
        }

        public override string MenuText()
        {
            return "Main Menu" + Environment.NewLine; 
        }
    }
}
