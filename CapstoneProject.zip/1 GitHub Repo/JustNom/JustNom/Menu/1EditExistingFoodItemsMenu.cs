﻿using JustNom.Food;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Menu
{
    internal class EditExistingFoodItemsMenu : ConsoleMenu
    {
        private Basket _basket;

        public EditExistingFoodItemsMenu(Basket pBasket)
        {
            _basket = pBasket;
        }

        public override string MenuText()
        {
            return "Edit an item in basket";
        }

        public override void CreateMenu()
        {
            _menuItems.Clear();
            Console.WriteLine("Select the item you would like to edit\n");
            foreach (FoodItem food in _basket.MyOrder)
            {
                switch (food)
                {
                    case Pizza:
                        _menuItems.Add(new EditPizzaMenu(food as Pizza));
                        break;
                    case Burger:
                        _menuItems.Add(new EditBurgerMenu(food as Burger));
                        break;
                }
            }
            _menuItems.Add(new ExitMenuItem(this));
        }
    }
}
