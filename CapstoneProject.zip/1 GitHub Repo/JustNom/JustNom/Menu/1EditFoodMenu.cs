﻿using JustNom.Food;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Menu
{
    internal class EditFoodMenu : ConsoleMenu
    {
        protected FoodItem _food;

        public EditFoodMenu(FoodItem pFood)
        {
            _food = pFood;
        }

        public override void CreateMenu()
        {
            _menuItems.Clear();
            Console.Clear();
            Console.WriteLine("Do you want to edit this item?\n1. Yes please\n2. No and its perfect :)\n");
            
            
        }

        public override string MenuText()
        {
            return _food.ToString();
            
        }

        public override string ToString()
        {
            
            _food.GetDetails();
            return "\n";
            //return $"Edit {base.ToString()}";
        }
    }
}
