﻿using JustNom.Food;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Menu
{
    internal class EditPizzaMenu : EditFoodMenu
    {
        private Food.Pizza _Pizza;

        public EditPizzaMenu(Food.Pizza pPizza) : base(pPizza)
        {
            _Pizza = pPizza;
        }

        public override void CreateMenu()
        {
            //Console.Clear();
            base.CreateMenu();
            // _menuItems.Add(new EditCircleRadiusMenuItem(_circle)); //EDIT RADIUS???????????
            _menuItems.Add(new AddToppingsMenuItem(_Pizza));
            _menuItems.Add(new ExitMenuItem(this));
        }
        
    }
}

