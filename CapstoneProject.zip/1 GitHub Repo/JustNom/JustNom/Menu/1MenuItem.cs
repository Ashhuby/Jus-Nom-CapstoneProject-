﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Menu
{
    internal abstract class MenuItem
    {
        //All menu items inherit from this class. All must provide the two methods below...
        //Note this class is abstract meaning you cannot create an instance of this base class.
        public abstract void Select();  // The 'action' that occurs when a child of this class is called
        public abstract string MenuText();  // The text that appears for this menu option
    }
}
