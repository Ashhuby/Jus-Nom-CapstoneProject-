﻿using JustNom.Food;
using System;

namespace JustNom.Menu
{
    internal class NewBasketMenuItem : MenuItem
    {
        private BasketManager _basketManager;

        public NewBasketMenuItem(BasketManager basketManager)
        {
            _basketManager = basketManager;
        }

        public override void Select()
        {
            // Create a new basket and add it to the basket manager
            Basket newBasket = new Basket();
            _basketManager.AddBasket(newBasket);
            BasketMenu basketMenu = new BasketMenu(newBasket); //Create an instance of the menusystem, as it is completely seperate from the resturant manager
            basketMenu.Select();
            Console.WriteLine("New basket created with ID: " + newBasket.PrintID());
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey(true);
        }

        public override string MenuText()
        {
            return "Create New Basket";
        }
    }
}
