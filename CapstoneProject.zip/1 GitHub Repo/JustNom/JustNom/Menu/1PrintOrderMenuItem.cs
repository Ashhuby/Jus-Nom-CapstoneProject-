﻿using JustNom.Data;
using JustNom.Food;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Menu 
{
    internal class PrintOrderMenuItem : MenuItem
    {
        private Basket _basket;
        public PrintOrderMenuItem(Basket pBasket) 
        {
            _basket = pBasket;
        }


        public override string MenuText()
        {
            return "Print Order";
        }

        /// <summary>
        /// This asks the user what theyd like to name the file and then prints out their order into a file with that name
        /// </summary>
        public override void Select()
        {
            Console.WriteLine("Will this order be delivery or pickup");
            Console.WriteLine("1. Delivery\n2. Pickup");
            int choice = Convert.ToInt32(Console.ReadLine());

            if(choice == 1)
            {
                Console.WriteLine("What is your address?");
                string Address = Console.ReadLine();

                _basket.AddDeliveryCharge(_basket);

                Console.WriteLine("What would you like to name your text file?");
                string FileName = Console.ReadLine();

                StreamWriter MyStreamWriter = new StreamWriter($"PrintedOrders//{FileName}");
                int number = ViewFilesMenuItem.ReturnChosenFileInt();
                string RestaurantName = RestaurantMenuMethods.ReturnFileNameString(number);

                int OrderNumber = _basket.PrintID();

                MyStreamWriter.Write(RestaurantName);
                MyStreamWriter.WriteLine("      Order #: " + OrderNumber);
                MyStreamWriter.WriteLine("Order Summary:");
                MyStreamWriter.WriteLine(_basket.ToString());
                MyStreamWriter.WriteLine("Delivery Charge      £2.00");
                MyStreamWriter.WriteLine("Delivery Address     " + Address);
                MyStreamWriter.WriteLine("Total Order Cost: " + _basket.ReturnTotalCost());

                MyStreamWriter.Close();
                Console.WriteLine("Order Saved Successfully!");
                Thread.Sleep(1000);
            }

            if (choice == 2)
            {

                Console.WriteLine("What would you like to name your text file?");
                string FileName = Console.ReadLine();

                StreamWriter MyStreamWriter = new StreamWriter($"PrintedOrders//{FileName}");
                int number = ViewFilesMenuItem.ReturnChosenFileInt();
                string RestaurantName = RestaurantMenuMethods.ReturnFileNameString(number);

                int OrderNumber = _basket.PrintID();

                MyStreamWriter.Write(RestaurantName);
                MyStreamWriter.WriteLine("      Order #: " + OrderNumber);
                MyStreamWriter.WriteLine("Order Summary:");
                MyStreamWriter.WriteLine(_basket.ToString());
                MyStreamWriter.WriteLine("Total Order Cost: " + _basket.ReturnTotalCost());

                MyStreamWriter.Close();
                Console.WriteLine("Order Saved Successfully!");
                Thread.Sleep(1000);
            }


        }


    }

}
