﻿using JustNom.Data;
using JustNom.Food;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Menu
{
    internal class ViewCurrentOrder : MenuItem
    {
        public const string FolderPath = "RestaurantData//";
        private Basket _basket;
        public ViewCurrentOrder(Basket basket)
        {
            _basket = basket;

        }

        public override string MenuText()   
        {
            return "View Current Order";
        }

        public override void Select()
        {
            Console.WriteLine("ORDER:\n" + _basket.ToString());
            Console.WriteLine("Total: £" + _basket.TotalCost);
            Thread.Sleep(2500); //Delay
        }
        
    }
}



