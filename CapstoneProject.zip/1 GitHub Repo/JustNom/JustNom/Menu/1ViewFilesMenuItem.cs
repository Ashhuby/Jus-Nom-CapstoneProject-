﻿using JustNom.Data;
using JustNom.Food;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustNom.Menu
{
    internal class ViewFilesMenuItem : MenuItem
    {
        public const string FolderPath = "RestaurantData//";
        public static int ChosenFileInt { get; set; }




        public ViewFilesMenuItem()
        {

            //ChosenFileInt = -1;
        }

        public override string MenuText()
        {
            return "Choose File";
        }

        //Method to chosen which file user would like to use
        public override void Select()
        {
            Console.Clear();
            RestaurantMenuMethods.AddFileNameToList();
            RestaurantMenuMethods.RestaurantFiles(FolderPath);
            //RestaurantMenuMethods.PrintFileNameList();
            

            int selection = ConsoleHelpers.GetIntegerInRange(1, RestaurantMenuMethods.RestaurantFilesCount(FolderPath), "\nPick the file you would like to import restaurant data from:");
            

            if (selection >= 0)
            {
                ChosenFileInt = selection;
                Console.Write("You chose ");
                Console.WriteLine(RestaurantMenuMethods.FileNameStringArray[ChosenFileInt]);
            }
            else
            {
                throw new Exception();
            }
            Thread.Sleep(750);  //Wait half a sec between menus COMPLETELY OPTIONAL CAN REMOVE IF PREFERED.
            Console.Clear();
        }

        public static int ReturnChosenFileInt()
        {
            int result = ChosenFileInt;
            return result; 
        }
        public static string ReturnChosenFileString()
        {
            string result = Convert.ToString(RestaurantMenuMethods.FileNameStringArray[ChosenFileInt]);
            return result;
        }

    }
}
