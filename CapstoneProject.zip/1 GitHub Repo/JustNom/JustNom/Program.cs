﻿using System;
using System.IO;
using JustNom.Data;
using JustNom.Food;
using JustNom.Menu;

class program
{
    static void Main()
    {
        /// Tab Key:
        /// 1: Menu System
        /// 2: Restaurant System
        /// 3: File Reading and Formatting System
        //READ THE README.TXT 
       


        ///StartProgram

        Basket basket = new Basket();   //Create the Basket for this order, each basket/order has its own ID
        BasketMenu basketMenu = new BasketMenu(basket); //Create an instance of the menusystem, as it is completely seperate from the resturant manager
        basketMenu.Select();  //Run Program


        Console.ReadKey();
    }
}